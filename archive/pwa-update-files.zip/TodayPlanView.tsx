'use client';

import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import {
  Sparkles,
  Check,
  Scale,
  Clock,
  Zap,
  Utensils,
  CheckCheck,
} from 'lucide-react';
import { DailyMenuDay, MealItemRecommendation, MealSlot, UserProfile } from '@/lib/types';
import { DISH_LOOKUP } from '@/lib/data/messDishes';
import { calculateFullMealPlan } from '@/lib/nutrition/fitScore';
import { saveStoredLog, getTodayDateStr, getDaySummary } from '@/lib/storage';
import { CircularMacroRing } from './CircularMacroRing';

interface TodayPlanViewProps {
  currentDayMenu: DailyMenuDay;
  profile: UserProfile;
  onMealLogged: () => void;
  isDark?: boolean;
}

const MEAL_SLOTS: { id: MealSlot; label: string; icon: string; timing: string }[] = [
  { id: 'breakfast', label: 'Breakfast', icon: '☕', timing: '7:30 AM – 9:30 AM' },
  { id: 'lunch', label: 'Lunch', icon: '🍛', timing: '12:30 PM – 2:30 PM' },
  { id: 'snacks', label: 'Snacks', icon: '🫖', timing: '5:00 PM – 6:30 PM' },
  { id: 'dinner', label: 'Dinner', icon: '🍲', timing: '7:45 PM – 9:45 PM' },
];

export const TodayPlanView: React.FC<TodayPlanViewProps> = ({
  currentDayMenu,
  profile,
  onMealLogged,
  isDark = false,
}) => {
  const [activeSlot, setActiveSlot] = useState<MealSlot>('lunch');
  const [expandedItemId, setExpandedItemId] = useState<string | null>(null);
  const [loggedItemsMap, setLoggedItemsMap] = useState<Record<string, boolean>>({});
  const [isFullMealLogged, setIsFullMealLogged] = useState(false);

  const todayStr = getTodayDateStr();
  const todaySummary = getDaySummary(todayStr, profile);

  // Retrieve dishes in today's menu for the selected meal slot
  const slotDishIds = currentDayMenu.slots[activeSlot] || [];
  const availableDishes = slotDishIds
    .map((id) => DISH_LOOKUP.get(id))
    .filter((d): d is NonNullable<typeof d> => Boolean(d));

  // Compute full-meal composition plan
  const fullMealPlan = calculateFullMealPlan(availableDishes, activeSlot, profile);
  const slotInfo = MEAL_SLOTS.find((s) => s.id === activeSlot) || MEAL_SLOTS[1];

  // Single-item log handler
  const handleLogSingleItem = (item: MealItemRecommendation) => {
    saveStoredLog({
      dateStr: todayStr,
      source: 'mess',
      mealSlot: activeSlot,
      dishId: item.dishId,
      dishName: item.dish.name,
      portionCount: item.portionMultiplier,
      calories: item.calories,
      protein: item.protein,
      carbs: item.carbs,
      fat: item.fat,
    });

    setLoggedItemsMap((prev) => ({ ...prev, [`${activeSlot}_${item.dishId}`]: true }));

    try {
      confetti({
        particleCount: 35,
        spread: 50,
        origin: { y: 0.8 },
        colors: ['#E04F16', '#2563EB', '#F59E0B', '#10B981'],
      });
    } catch (e) {}

    onMealLogged();
  };

  // Full-meal log handler
  const handleLogFullMeal = () => {
    const activeItems = fullMealPlan.items.filter((i) => i.quantityIndicator !== 'skip');
    if (activeItems.length === 0) return;

    activeItems.forEach((item) => {
      saveStoredLog({
        dateStr: todayStr,
        source: 'mess',
        mealSlot: activeSlot,
        dishId: item.dishId,
        dishName: item.dish.name,
        portionCount: item.portionMultiplier,
        calories: item.calories,
        protein: item.protein,
        carbs: item.carbs,
        fat: item.fat,
      });
    });

    setIsFullMealLogged(true);

    try {
      confetti({
        particleCount: 75,
        spread: 70,
        origin: { y: 0.75 },
        colors: ['#E04F16', '#2563EB', '#F59E0B', '#10B981'],
      });
    } catch (e) {}

    onMealLogged();
  };

  const getIndicatorBadgeStyle = (indicator: MealItemRecommendation['quantityIndicator']) => {
    switch (indicator) {
      case 'increase':
        return 'bg-blue-50 border-blue-200 text-blue-700 font-bold';
      case 'reduce':
        return 'bg-amber-50 border-amber-200 text-amber-700 font-bold';
      case 'skip':
        return 'bg-red-50 border-red-200 text-red-600 font-bold';
      case 'standard':
      default:
        return 'bg-emerald-50 border-emerald-200 text-emerald-700 font-bold';
    }
  };

  return (
    <div className="space-y-4 pb-20 animate-fade-in">
      {/* 1. MACRO PROGRESS RING HERO CARD */}
      <div className="bg-white border border-gray-150/80 rounded-3xl p-5 shadow-xs">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-2">
            <span className="text-[11px] font-bold text-blue-600 bg-blue-50 border border-blue-200/70 px-2.5 py-0.5 rounded-full">
              Day {currentDayMenu.dayNumber} of 30
            </span>
            <span className="text-xs text-gray-500 font-semibold">
              {currentDayMenu.dayOfWeek}
            </span>
          </div>
          <div className="flex items-center space-x-1 text-xs text-[#E04F16] font-bold">
            <Sparkles className="w-3.5 h-3.5 text-[#E04F16]" />
            <span>Target: {profile.targetCalories} kcal</span>
          </div>
        </div>

        <div className="py-2">
          <CircularMacroRing
            calorieTarget={profile.targetCalories}
            calorieConsumed={todaySummary.caloriesConsumed}
            proteinTarget={profile.targetProteinG}
            proteinConsumed={todaySummary.proteinConsumed}
            carbsTarget={profile.targetCarbsG}
            carbsConsumed={todaySummary.carbsConsumed}
            isDark={isDark}
          />
        </div>
      </div>

      {/* 2. MEAL SLOT SELECTOR TABS */}
      <div className="grid grid-cols-4 gap-1.5 bg-white p-1.5 rounded-2xl border border-gray-150/80 shadow-xs">
        {MEAL_SLOTS.map((slot) => {
          const isActive = activeSlot === slot.id;
          return (
            <button
              key={slot.id}
              onClick={() => {
                setActiveSlot(slot.id);
                setExpandedItemId(null);
                setIsFullMealLogged(false);
              }}
              className={`py-2.5 px-1 rounded-xl text-center transition-all duration-200 cursor-pointer ${
                isActive
                  ? 'bg-[#E04F16] text-white shadow-sm font-bold active:scale-95'
                  : 'text-gray-500 hover:text-gray-900 hover:bg-gray-50 font-medium'
              }`}
            >
              <div className="text-base leading-none mb-1">{slot.icon}</div>
              <div className="text-[11px] font-bold truncate tracking-tight">{slot.label}</div>
            </button>
          );
        })}
      </div>

      {/* 3. FULL-MEAL COMPOSITION HEADER */}
      <div className="bg-white border border-gray-150/80 rounded-2xl p-4 shadow-xs">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">
              Full Meal Composition
            </span>
            <h2 className="text-base font-extrabold text-gray-900 mt-0.5">
              Today&apos;s {slotInfo.label}
            </h2>
          </div>

          {/* Overall Meal Fit Score Badge */}
          <div className="flex items-center space-x-1.5 bg-amber-50 border border-amber-200 px-3 py-1 rounded-full shadow-xs">
            <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
            <span className="text-xs font-black text-amber-800">
              {fullMealPlan.overallFitScore}% Fit
            </span>
          </div>
        </div>

        {/* Plate Totals Glance */}
        <div className="mt-3 pt-2.5 border-t border-gray-100 flex items-center justify-between text-xs text-gray-600">
          <div className="flex items-center space-x-2">
            <Clock className="w-3.5 h-3.5 text-[#E04F16]" />
            <span>Counter: <strong className="text-gray-800">{slotInfo.timing}</strong></span>
          </div>
          <div className="text-right">
            <span className="text-gray-900 font-bold">{fullMealPlan.totalCalories} kcal</span>
            <span className="text-gray-300 mx-1">•</span>
            <span className="text-blue-600 font-bold">{fullMealPlan.totalProtein}g protein</span>
          </div>
        </div>
      </div>

      {/* 4. DISHES STACK */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-bold text-gray-800">
            Recommended Meal Plate ({fullMealPlan.items.length} items on counter)
          </span>
          <span className="text-[10px] text-gray-400 font-medium">
            Goal: {profile.goal}
          </span>
        </div>

        {fullMealPlan.items.map((item) => {
          const isExpanded = expandedItemId === item.dishId;
          const isItemLogged = loggedItemsMap[`${activeSlot}_${item.dishId}`];
          const isSkip = item.quantityIndicator === 'skip';

          return (
            <div
              key={item.dishId}
              className={`rounded-2xl border transition-all duration-200 overflow-hidden bg-white ${
                item.isTopPick
                  ? 'border-amber-300 shadow-sm'
                  : isSkip
                  ? 'border-gray-100 opacity-60 bg-gray-50/60'
                  : 'border-gray-150/80 shadow-xs hover:border-gray-300'
              }`}
            >
              {/* Top Pick Banner */}
              {item.isTopPick && (
                <div className="bg-gradient-to-r from-amber-100/90 via-orange-50 to-transparent px-3.5 py-1 border-b border-amber-200 flex items-center justify-between">
                  <div className="flex items-center space-x-1.5 text-[10px] font-black tracking-wide text-amber-800">
                    <Sparkles className="w-3 h-3 text-amber-600" />
                    <span>⭐ TOP PICK FOR THIS MEAL</span>
                  </div>
                  <span className="text-[10px] font-bold text-amber-700">{item.score}% Match</span>
                </div>
              )}

              {/* Compact Card Content */}
              <div
                className="p-3.5 cursor-pointer"
                onClick={() => setExpandedItemId(isExpanded ? null : item.dishId)}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    {/* Item Name & Tags */}
                    <div className="flex flex-wrap items-center gap-1.5 mb-1">
                      <span className="font-bold text-sm text-gray-900 truncate">
                        {item.dish.name}
                      </span>
                      {item.dish.portionStatus === 'measured' ? (
                        <span className="inline-flex items-center space-x-0.5 text-[9px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.2 rounded">
                          <Scale className="w-2.5 h-2.5" />
                          <span>Measured</span>
                        </span>
                      ) : (
                        <span className="text-[9px] text-gray-500 bg-gray-100 px-1.5 py-0.2 rounded font-medium">
                          Estimated
                        </span>
                      )}
                    </div>

                    {/* Recommended Serving & Quantity Badge */}
                    <div className="flex items-center space-x-2 text-xs">
                      <span className="text-gray-700 font-medium">
                        {item.recommendedServing}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getIndicatorBadgeStyle(
                          item.quantityIndicator
                        )}`}
                      >
                        {item.indicatorLabel}
                      </span>
                    </div>

                    {/* 1-Line "Why this fits" */}
                    <p className="text-[11px] text-gray-500 mt-1.5 line-clamp-1 leading-tight font-medium">
                      💡 {item.quickReason}
                    </p>
                  </div>

                  {/* Macro Glance */}
                  <div className="text-right shrink-0 flex flex-col items-end">
                    <div className="bg-gray-50 border border-gray-150 px-2.5 py-1 rounded-xl text-center min-w-[70px]">
                      <span className="text-xs font-extrabold text-gray-900 block leading-tight">
                        {item.calories} kcal
                      </span>
                      <span className="text-[10px] font-bold text-blue-600 block leading-tight mt-0.5">
                        {item.protein}g protein
                      </span>
                    </div>

                    {/* Item Log Action */}
                    {!isSkip && (
                      <div className="mt-2">
                        {isItemLogged ? (
                          <span className="inline-flex items-center space-x-1 text-[11px] font-bold text-emerald-600">
                            <Check className="w-3.5 h-3.5" />
                            <span>Logged</span>
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleLogSingleItem(item);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-[#E04F16] text-white text-[10px] font-bold hover:bg-[#C84310] active:scale-95 transition-all shadow-xs cursor-pointer"
                          >
                            I Ate This
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Expandable Details */}
              {isExpanded && (
                <div className="px-3.5 pb-3.5 pt-2 border-t border-gray-100 space-y-2.5 text-xs bg-gray-50/50">
                  <div className="text-gray-700 leading-relaxed bg-white p-2.5 rounded-xl border border-gray-200">
                    <span className="font-bold text-gray-900 block mb-0.5">
                      Clinical Nutrition Reasoning:
                    </span>
                    {item.fullReason}
                  </div>

                  {/* Macro Breakdown */}
                  <div className="grid grid-cols-4 gap-2 text-center text-gray-700">
                    <div className="bg-white p-2 rounded-xl border border-gray-150">
                      <div className="text-[9px] text-gray-400 uppercase font-semibold">Portion</div>
                      <div className="font-bold text-gray-900 mt-0.5">{item.portionMultiplier}x</div>
                    </div>
                    <div className="bg-white p-2 rounded-xl border border-gray-150">
                      <div className="text-[9px] text-blue-500 uppercase font-semibold">Protein</div>
                      <div className="font-bold text-blue-600 mt-0.5">{item.protein}g</div>
                    </div>
                    <div className="bg-white p-2 rounded-xl border border-gray-150">
                      <div className="text-[9px] text-gray-400 uppercase font-semibold">Carbs</div>
                      <div className="font-bold text-gray-900 mt-0.5">{item.carbs}g</div>
                    </div>
                    <div className="bg-white p-2 rounded-xl border border-gray-150">
                      <div className="text-[9px] text-gray-400 uppercase font-semibold">Fats</div>
                      <div className="font-bold text-gray-900 mt-0.5">{item.fat}g</div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* 5. LOG FULL MEAL BUTTON */}
      <div className="pt-2">
        {isFullMealLogged ? (
          <div className="w-full py-3.5 px-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-center font-bold text-xs flex items-center justify-center space-x-2 shadow-xs">
            <CheckCheck className="w-4 h-4 text-emerald-600" />
            <span>Full Plate Logged ({fullMealPlan.totalCalories} kcal • {fullMealPlan.totalProtein}g protein)</span>
          </div>
        ) : (
          <button
            onClick={handleLogFullMeal}
            className="w-full py-3.5 px-4 rounded-2xl bg-[#E04F16] hover:bg-[#C84310] text-white font-bold text-sm shadow-sm hover:opacity-95 active:scale-98 transition-all flex items-center justify-center space-x-2 cursor-pointer"
          >
            <Utensils className="w-4 h-4" />
            <span>
              Log Full Meal ({fullMealPlan.totalCalories} kcal • {fullMealPlan.totalProtein}g Protein)
            </span>
          </button>
        )}
        <p className="text-[11px] text-gray-400 text-center mt-1.5 font-medium">
          One tap logs all {fullMealPlan.items.filter((i) => i.quantityIndicator !== 'skip').length} recommended dishes at once.
        </p>
      </div>
    </div>
  );
};
