'use client';

import React, { useState, useMemo } from 'react';
import confetti from 'canvas-confetti';
import {
  Search,
  Plus,
  Check,
  HeartHandshake,
  ArrowLeft,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { FoodCourtItem, FoodCourtShop, UserProfile } from '@/lib/types';
import {
  FOOD_COURT_SHOPS,
  RAW_FOOD_COURT_ITEMS,
  enrichFoodCourtItems,
} from '@/lib/data/foodCourtItems';
import { saveStoredLog, getStoredLogs, getTodayDateStr } from '@/lib/storage';

interface FoodCourtLoggerProps {
  profile: UserProfile;
  onLogUpdated: () => void;
}

export const FoodCourtLogger: React.FC<FoodCourtLoggerProps> = ({
  profile,
  onLogUpdated,
}) => {
  const [selectedShop, setSelectedShop] = useState<FoodCourtShop | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const todayStr = getTodayDateStr();
  const allLogs = getStoredLogs();
  const todayLogs = allLogs.filter((l) => l.dateStr === todayStr);

  const caloriesConsumed = todayLogs.reduce((sum, l) => sum + l.calories, 0);
  const proteinConsumed = Math.round(todayLogs.reduce((sum, l) => sum + l.protein, 0) * 10) / 10;

  const caloriePercent = Math.min(125, Math.round((caloriesConsumed / profile.targetCalories) * 100));
  const proteinPercent = Math.min(125, Math.round((proteinConsumed / profile.targetProteinG) * 100));

  const enrichedItems = useMemo(() => {
    return enrichFoodCourtItems(RAW_FOOD_COURT_ITEMS, profile.goal);
  }, [profile.goal]);

  const recentItemIds = Array.from(
    new Set(allLogs.filter((l) => l.source === 'food_court').map((l) => l.dishId))
  ).slice(0, 3);
  const recentItems = recentItemIds
    .map((id) => enrichedItems.find((f) => f.id === id))
    .filter((f): f is FoodCourtItem => Boolean(f));

  const handleLogFoodCourtItem = (item: FoodCourtItem) => {
    saveStoredLog({
      dateStr: todayStr,
      source: 'food_court',
      mealSlot: 'snacks',
      dishId: item.id,
      dishName: `${item.name} (${item.shopName})`,
      portionCount: 1.0,
      calories: item.calories,
      protein: item.protein,
      carbs: item.carbs,
      fat: item.fat,
    });

    setSuccessNotice(`Logged ${item.name} (₹${item.price})!`);
    setTimeout(() => setSuccessNotice(null), 2500);

    try {
      confetti({
        particleCount: 35,
        spread: 50,
        origin: { y: 0.85 },
        colors: ['#E04F16', '#2563EB', '#10B981'],
      });
    } catch (e) {}

    onLogUpdated();
  };

  const getBudgetFeedback = () => {
    if (caloriePercent < 50) {
      return 'Plenty of daily room remaining for hearty mess meals.';
    } else if (caloriePercent <= 85) {
      return 'Nicely balanced today — perfectly on pace with your campus goals.';
    } else if (caloriePercent <= 100) {
      return "You're nearly at target — solid energy for evening studies or training.";
    } else {
      return "You're well fueled today! You've got room for a lighter mess dinner (dal + salad).";
    }
  };

  const shopItems = useMemo(() => {
    if (!selectedShop) return [];
    return enrichedItems.filter((i) => i.shopId === selectedShop.id);
  }, [selectedShop, enrichedItems]);

  const searchResults = useMemo(() => {
    if (!searchTerm.trim()) return [];
    return enrichedItems.filter(
      (i) =>
        i.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        i.shopName.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm, enrichedItems]);

  const getShopMatchStats = (shopId: string) => {
    const items = enrichedItems.filter((i) => i.shopId === shopId);
    const compliant = items.filter((i) => {
      if (profile.dietPreference === 'veg') return i.category === 'veg';
      if (profile.dietPreference === 'egg') return i.category === 'veg' || i.category === 'egg';
      return true;
    });
    const bestValueItem = items.find((i) => i.isBestValue);
    return {
      total: items.length,
      matchCount: compliant.length,
      bestValueItem,
    };
  };

  return (
    <div className="space-y-4 pb-20 animate-fade-in">
      {/* 1. RUNNING DAILY FUEL BAR */}
      <div className="bg-white rounded-3xl p-5 border border-gray-150/80 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
              Running Daily Fuel
            </span>
            <div className="text-2xl font-extrabold text-gray-900 mt-0.5">
              {caloriesConsumed}{' '}
              <span className="text-xs font-normal text-gray-500 font-sans">
                / {profile.targetCalories} kcal
              </span>
            </div>
          </div>
          <div className="text-right">
            <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest">
              Protein
            </span>
            <div className="text-2xl font-extrabold text-blue-600 mt-0.5">
              {proteinConsumed}g{' '}
              <span className="text-xs font-normal text-gray-500 font-sans">
                / {profile.targetProteinG}g
              </span>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="space-y-1.5 pt-1">
          <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden flex">
            <div
              className="h-full transition-all duration-500 rounded-full bg-[#E04F16]"
              style={{ width: `${Math.min(100, caloriePercent)}%` }}
            />
          </div>
          <div className="flex justify-between text-[10px] text-gray-500 font-medium">
            <span>{caloriePercent}% daily calories</span>
            <span className="text-blue-600 font-bold">{proteinPercent}% protein</span>
          </div>
        </div>

        {/* Reassurance Banner */}
        <div className="bg-gray-50 border border-gray-150 p-3 rounded-2xl flex items-center space-x-2 text-xs text-gray-600">
          <HeartHandshake className="w-4 h-4 text-[#E04F16] shrink-0" />
          <span className="text-[11px] leading-tight font-medium">{getBudgetFeedback()}</span>
        </div>
      </div>

      {/* Success alert notification */}
      {successNotice && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-2.5 rounded-2xl text-xs font-bold flex items-center space-x-2 shadow-xs animate-in fade-in">
          <Check className="w-4 h-4 text-emerald-600" />
          <span>{successNotice}</span>
        </div>
      )}

      {/* STEP 1: SHOP SELECTION SCREEN */}
      {!selectedShop ? (
        <div className="space-y-4">
          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search campus rolls, dosa, maggi, shakes..."
              className="w-full pl-9 pr-3 py-2.5 rounded-2xl bg-white border border-gray-200 text-gray-900 placeholder:text-gray-400 focus:outline-hidden focus:border-blue-500 text-xs shadow-xs"
            />
          </div>

          {/* Active Search Results */}
          {searchTerm.trim().length > 0 ? (
            <div className="bg-white rounded-3xl p-4 border border-gray-150/80 shadow-xs space-y-2">
              <div className="flex items-center justify-between pb-2 border-b border-gray-100">
                <span className="text-xs font-bold text-gray-900">Search Results ({searchResults.length})</span>
                <button
                  onClick={() => setSearchTerm('')}
                  className="text-[11px] text-[#E04F16] font-bold"
                >
                  Clear
                </button>
              </div>

              <div className="space-y-2 pt-1">
                {searchResults.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 rounded-2xl border border-gray-150 bg-gray-50/60 flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-xs text-gray-900">{item.name}</span>
                        <span className="text-[10px] font-bold text-[#E04F16]">₹{item.price}</span>
                      </div>
                      <div className="text-[11px] text-gray-500 mt-0.5">{item.shopName}</div>
                      <div className="text-[11px] text-gray-600 mt-0.5">
                        {item.calories} kcal • <strong className="text-blue-600">{item.protein}g protein</strong>
                      </div>
                    </div>

                    <button
                      onClick={() => handleLogFoodCourtItem(item)}
                      className="px-3 py-1.5 rounded-xl bg-[#E04F16] text-white font-bold text-xs active:scale-95 transition-all shadow-xs shrink-0 cursor-pointer"
                    >
                      + Log
                    </button>
                  </div>
                ))}
                {searchResults.length === 0 && (
                  <p className="text-xs text-gray-400 py-3 text-center">No matching food court items found.</p>
                )}
              </div>
            </div>
          ) : (
            <>
              {/* RECENTLY ORDERED QUICK TAP */}
              {recentItems.length > 0 && (
                <div className="bg-white rounded-3xl p-4 border border-gray-150/80 shadow-xs space-y-2">
                  <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                    Recently Eaten (Quick Tap)
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {recentItems.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => handleLogFoodCourtItem(item)}
                        className="flex items-center space-x-1.5 bg-gray-50 border border-gray-200 hover:border-[#E04F16] px-3 py-1.5 rounded-xl text-xs text-gray-800 font-medium active:scale-95 transition-all cursor-pointer"
                      >
                        <span>{item.name}</span>
                        <span className="text-[10px] text-[#E04F16] font-bold">₹{item.price}</span>
                        <Plus className="w-3.5 h-3.5 text-[#E04F16]" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* VENDOR SHOP CARDS LIST */}
              <div className="space-y-3">
                <div className="flex items-center justify-between px-1">
                  <span className="text-xs font-bold text-gray-800">
                    Campus Food Court Stalls ({FOOD_COURT_SHOPS.length} Vendors)
                  </span>
                  <span className="text-[10px] text-gray-400 font-medium">Tap to inspect menu</span>
                </div>

                {FOOD_COURT_SHOPS.map((shop) => {
                  const { matchCount, bestValueItem } = getShopMatchStats(shop.id);
                  return (
                    <div
                      key={shop.id}
                      onClick={() => setSelectedShop(shop)}
                      className="bg-white hover:bg-gray-50/80 border border-gray-150/80 hover:border-gray-300 rounded-3xl p-4 transition-all duration-200 cursor-pointer shadow-xs active:scale-98"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-3">
                          <div className="w-11 h-11 rounded-2xl bg-gray-50 border border-gray-200 flex items-center justify-center text-xl shadow-xs shrink-0">
                            {shop.icon}
                          </div>

                          <div>
                            <div className="flex items-center space-x-2">
                              <h3 className="font-bold text-sm text-gray-900">
                                {shop.name}
                              </h3>
                            </div>
                            <p className="text-[11px] text-gray-500 mt-0.5 line-clamp-1">
                              {shop.tagline}
                            </p>

                            <div className="flex flex-wrap items-center gap-2 mt-2">
                              <span className="text-[11px] font-bold text-gray-900 bg-gray-100 px-2 py-0.5 rounded-lg border border-gray-200">
                                {shop.priceRange}
                              </span>

                              <span className="text-[10px] text-gray-500 font-medium">
                                Popular: <strong className="text-gray-800">{shop.popularItemName}</strong>
                              </span>
                            </div>
                          </div>
                        </div>

                        <ChevronRight className="w-4 h-4 text-gray-400 mt-1 shrink-0" />
                      </div>

                      {/* Goal Fit & Best Value Teaser Badge */}
                      <div className="mt-3 pt-2.5 border-t border-gray-100 flex items-center justify-between text-[10px]">
                        <span className="text-emerald-800 font-bold bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full">
                          {matchCount} items fit your {profile.goal} goal
                        </span>

                        {bestValueItem && (
                          <span className="text-amber-800 font-bold bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full flex items-center space-x-1">
                            <Sparkles className="w-3 h-3 text-amber-600" />
                            <span>Best Value: {bestValueItem.name}</span>
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
      ) : (
        /* STEP 2: SHOP ITEM LIST */
        <div className="space-y-3 animate-fade-in">
          {/* Shop Header & Back Button */}
          <div className="bg-white border border-gray-150/80 rounded-3xl p-4 shadow-xs flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setSelectedShop(null)}
                className="p-2 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 transition-colors cursor-pointer"
                title="Back to all shops"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>

              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-base">{selectedShop.icon}</span>
                  <h3 className="font-bold text-sm text-gray-900">
                    {selectedShop.name}
                  </h3>
                </div>
                <span className="text-[11px] text-gray-500">
                  {shopItems.length} items • {selectedShop.priceRange}
                </span>
              </div>
            </div>

            <button
              onClick={() => setSelectedShop(null)}
              className="text-[11px] font-bold text-[#E04F16] hover:underline cursor-pointer"
            >
              All Shops
            </button>
          </div>

          {/* Shop Items List */}
          <div className="space-y-2.5">
            {shopItems.map((item) => (
              <div
                key={item.id}
                className={`p-4 rounded-3xl border transition-all duration-200 bg-white ${
                  item.isBestValue
                    ? 'border-amber-300 shadow-sm'
                    : 'border-gray-150/80 shadow-xs hover:border-gray-300'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 pr-2">
                    <div className="flex items-center space-x-2">
                      <h4 className="font-bold text-sm text-gray-900 leading-snug">
                        {item.name}
                      </h4>
                      {item.isBestValue && (
                        <span className="text-[9px] font-black uppercase text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.2 rounded-full">
                          ⭐ Best Value
                        </span>
                      )}
                    </div>

                    <p className="text-[11px] text-gray-500 mt-0.5 line-clamp-1">
                      {item.portionDescription}
                    </p>

                    <div className="flex items-center space-x-2 mt-2 text-xs">
                      <span className="font-extrabold text-[#E04F16]">₹{item.price}</span>
                      <span className="text-gray-300">•</span>
                      <span className="text-gray-600 font-semibold">{item.calories} kcal</span>
                      <span className="text-gray-300">•</span>
                      <span className="text-blue-600 font-bold">{item.protein}g protein</span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleLogFoodCourtItem(item)}
                    className="px-3.5 py-1.5 rounded-xl bg-[#E04F16] hover:bg-[#C84310] text-white font-bold text-xs shadow-xs active:scale-95 transition-all shrink-0 cursor-pointer"
                  >
                    + Log
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
