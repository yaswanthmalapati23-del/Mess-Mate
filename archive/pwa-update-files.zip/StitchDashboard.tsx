'use client';

import React from 'react';
import {
  Utensils,
  PlusCircle,
  TrendingUp,
  Flame,
  Calendar,
  Coffee,
  ChevronDown,
  ChevronRight,
  CheckCircle2,
  ArrowRight,
} from 'lucide-react';
import { UserProfile, DailyMenuDay, DailyTrackingSummary } from '@/lib/types';

interface StitchDashboardProps {
  profile: UserProfile;
  studentEmail?: string;
  currentDayMenu: DailyMenuDay;
  todaySummary?: DailyTrackingSummary;
  streakCount: number;
  onOpenViewPlan: () => void;
  onNavigateTab: (tab: 'home' | 'dining' | 'log' | 'monthly' | 'tracker') => void;
  onOpenLogMeal: () => void;
  onOpenProfile: () => void;
}

const BurgerIcon = ({ className = 'w-5 h-5' }: { className?: string }) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <path d="M4 11h16a1 1 0 0 0 .8-1.6C19.7 7.7 16.2 5 12 5S4.3 7.7 3.2 9.4A1 1 0 0 0 4 11z" />
    <path d="M4 15h16" />
    <path d="M5 19h14a2 2 0 0 0 2-2H3a2 2 0 0 0 2 2z" />
  </svg>
);

export const StitchDashboard: React.FC<StitchDashboardProps> = ({
  profile,
  studentEmail,
  todaySummary,
  streakCount,
  onOpenViewPlan,
  onNavigateTab,
  onOpenLogMeal,
  onOpenProfile,
}) => {
  // Calorie and macro metrics
  const consumedCalories = (todaySummary?.caloriesConsumed ?? 0) > 0 ? todaySummary!.caloriesConsumed : 1240;
  const targetCalories = profile.targetCalories || 1900;
  const consumedProtein = (todaySummary?.proteinConsumed ?? 0) > 0 ? Math.round(todaySummary!.proteinConsumed) : 65;
  const targetProtein = profile.targetProteinG || 70;
  const proteinPercent = Math.min(100, Math.round((consumedProtein / targetProtein) * 100)) || 82;

  // Meal logs count
  const loggedMealsCount = (todaySummary?.loggedCount ?? 0) > 0 ? Math.min(4, todaySummary!.loggedCount) : 3;

  const hostelDisplay = profile.hostelBlock || 'Mens Mess 2';
  const campusDisplay = studentEmail?.includes('vitap') ? 'VIT-AP' : 'VIT Vellore';

  return (
    <div className="space-y-4 pb-4 animate-fade-in">
      {/* 1. Date & Campus Status Header */}
      <div className="flex items-center justify-between pt-1">
        <div>
          <h2 className="text-2xl font-extrabold text-gray-900 tracking-tight leading-tight">
            Today
          </h2>
          <p className="text-xs font-medium text-gray-500 mt-0.5">
            {campusDisplay} • {hostelDisplay}
          </p>
        </div>

        {/* 3 of 4 logged pill badge */}
        <div className="flex items-center space-x-1.5 bg-[#EBF3FE] text-[#2563EB] border border-[#BFDBFE]/70 px-3 py-1 rounded-full text-xs font-semibold shadow-xs select-none">
          <CheckCircle2 className="w-3.5 h-3.5 text-[#2563EB] shrink-0" />
          <span>{loggedMealsCount} of 4 logged</span>
        </div>
      </div>

      {/* 2. Hero Feature Card */}
      <div className="bg-white rounded-3xl p-5 shadow-xs border border-gray-150/80 flex flex-col items-center text-center relative overflow-hidden">
        {/* Subtle decorative food emblem */}
        <div className="w-full flex items-center justify-center py-2">
          <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-orange-100 via-amber-50 to-orange-50 border border-orange-200/50 flex items-center justify-center shadow-inner relative">
            <span className="text-5xl select-none filter drop-shadow-sm">🍲</span>
            <div className="absolute -bottom-1 -right-1 bg-white rounded-full p-1 border border-gray-100 shadow-xs">
              <span className="text-base leading-none">🥗</span>
            </div>
          </div>
        </div>

        {/* Heading */}
        <h3 className="text-xl font-extrabold text-gray-900 tracking-tight mt-2 max-w-[280px]">
          All meals logged. Nice work today.
        </h3>

        {/* Nutrition Subtext */}
        <p className="text-xs text-gray-500 font-medium mt-1.5">
          {consumedCalories.toLocaleString()} kcal consumed • {consumedProtein}g protein
        </p>

        {/* Status bullets */}
        <div className="flex items-center justify-center space-x-1.5 text-xs text-gray-600 font-medium mt-3.5">
          <span className="w-2 h-2 rounded-full bg-[#E04F16] inline-block shrink-0" />
          <span>Lunch was ready • Dinner logged</span>
        </div>

        {/* View Plan Primary CTA */}
        <button
          onClick={onOpenViewPlan}
          className="w-full bg-[#E04F16] hover:bg-[#C84310] active:scale-[0.99] text-white font-bold py-3.5 px-6 rounded-2xl flex items-center justify-center space-x-2 text-sm shadow-sm transition-all mt-4 cursor-pointer"
        >
          <span>View Plan</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* 3. Quick Access 8-Icon Grid */}
      <div className="space-y-2.5 pt-1">
        <div className="flex items-center justify-between px-0.5">
          <span className="text-xs font-bold text-gray-900 uppercase tracking-wider">
            QUICK ACCESS
          </span>
          <button
            onClick={() => onNavigateTab('home')}
            className="text-xs font-semibold text-[#2563EB] hover:underline cursor-pointer"
          >
            Reorder
          </button>
        </div>

        {/* 2 Rows x 4 Columns */}
        <div className="grid grid-cols-4 gap-y-3.5 gap-x-2">
          {/* 1. Today's Menu */}
          <div className="flex flex-col items-center">
            <button
              onClick={onOpenViewPlan}
              className="w-14 h-14 rounded-full bg-white border border-gray-200/90 shadow-xs flex items-center justify-center text-[#2563EB] hover:border-blue-300 hover:shadow-sm active:scale-95 transition-all cursor-pointer"
            >
              <Utensils className="w-5 h-5" />
            </button>
            <span className="text-[11px] font-medium text-gray-800 text-center mt-1.5 line-clamp-1">
              Today&apos;s Menu
            </span>
          </div>

          {/* 2. Food Court */}
          <div className="flex flex-col items-center">
            <button
              onClick={() => onNavigateTab('dining')}
              className="w-14 h-14 rounded-full bg-white border border-gray-200/90 shadow-xs flex items-center justify-center text-[#E04F16] hover:border-orange-300 hover:shadow-sm active:scale-95 transition-all cursor-pointer"
            >
              <BurgerIcon className="w-5 h-5" />
            </button>
            <span className="text-[11px] font-medium text-gray-800 text-center mt-1.5 line-clamp-1">
              Food Court
            </span>
          </div>

          {/* 3. Log Meal */}
          <div className="flex flex-col items-center">
            <button
              onClick={onOpenLogMeal}
              className="w-14 h-14 rounded-full bg-white border border-gray-200/90 shadow-xs flex items-center justify-center text-[#2563EB] hover:border-blue-300 hover:shadow-sm active:scale-95 transition-all cursor-pointer"
            >
              <PlusCircle className="w-5 h-5" />
            </button>
            <span className="text-[11px] font-medium text-gray-800 text-center mt-1.5 line-clamp-1">
              Log Meal
            </span>
          </div>

          {/* 4. Progress */}
          <div className="flex flex-col items-center">
            <button
              onClick={() => onNavigateTab('tracker')}
              className="w-14 h-14 rounded-full bg-white border border-gray-200/90 shadow-xs flex items-center justify-center text-[#2563EB] hover:border-blue-300 hover:shadow-sm active:scale-95 transition-all cursor-pointer"
            >
              <TrendingUp className="w-5 h-5" />
            </button>
            <span className="text-[11px] font-medium text-gray-800 text-center mt-1.5 line-clamp-1">
              Progress
            </span>
          </div>

          {/* 5. Streaks */}
          <div className="flex flex-col items-center">
            <button
              onClick={() => onNavigateTab('tracker')}
              className="w-14 h-14 rounded-full bg-white border border-gray-200/90 shadow-xs flex items-center justify-center text-[#E04F16] hover:border-orange-300 hover:shadow-sm active:scale-95 transition-all cursor-pointer"
            >
              <Flame className="w-5 h-5" />
            </button>
            <span className="text-[11px] font-medium text-gray-800 text-center mt-1.5 line-clamp-1">
              Streaks
            </span>
          </div>

          {/* 6. 30-Day Plan */}
          <div className="flex flex-col items-center">
            <button
              onClick={() => onNavigateTab('monthly')}
              className="w-14 h-14 rounded-full bg-white border border-gray-200/90 shadow-xs flex items-center justify-center text-[#2563EB] hover:border-blue-300 hover:shadow-sm active:scale-95 transition-all cursor-pointer"
            >
              <Calendar className="w-5 h-5" />
            </button>
            <span className="text-[11px] font-medium text-gray-800 text-center mt-1.5 line-clamp-1">
              30-Day Plan
            </span>
          </div>

          {/* 7. Canteen */}
          <div className="flex flex-col items-center">
            <button
              onClick={() => onNavigateTab('dining')}
              className="w-14 h-14 rounded-full bg-white border border-gray-200/90 shadow-xs flex items-center justify-center text-[#E04F16] hover:border-orange-300 hover:shadow-sm active:scale-95 transition-all cursor-pointer"
            >
              <Coffee className="w-5 h-5" />
            </button>
            <span className="text-[11px] font-medium text-gray-800 text-center mt-1.5 line-clamp-1">
              Canteen
            </span>
          </div>

          {/* 8. More */}
          <div className="flex flex-col items-center">
            <button
              onClick={onOpenProfile}
              className="w-14 h-14 rounded-full bg-white border border-gray-200/90 shadow-xs flex items-center justify-center text-gray-700 hover:border-gray-400 hover:shadow-sm active:scale-95 transition-all cursor-pointer"
            >
              <ChevronDown className="w-5 h-5" />
            </button>
            <span className="text-[11px] font-medium text-gray-800 text-center mt-1.5 line-clamp-1">
              More
            </span>
          </div>
        </div>
      </div>

      {/* 4. For You Section (Horizontal Scrollable Cards) */}
      <div className="space-y-2.5 pt-1">
        <div className="flex items-center justify-between px-0.5">
          <span className="text-lg font-bold text-gray-900 tracking-tight">
            For You
          </span>
          <button
            onClick={() => onNavigateTab('tracker')}
            className="text-xs font-semibold text-[#2563EB] hover:underline cursor-pointer"
          >
            View All
          </button>
        </div>

        <div className="flex space-x-3 overflow-x-auto no-scrollbar pb-1 pt-0.5 -mx-4 px-4">
          {/* Card 1: Protein Trend */}
          <div className="w-[250px] shrink-0 bg-white rounded-2xl p-4 shadow-xs border border-gray-150/80 flex flex-col justify-between hover:border-gray-300 transition-all">
            <div>
              <div className="flex items-center justify-between">
                <span className="bg-[#EFF6FF] text-[#2563EB] text-[10px] font-bold px-2.5 py-0.5 rounded-full select-none">
                  On track +12%
                </span>
                <TrendingUp className="w-4 h-4 text-[#2563EB]" />
              </div>
              <h4 className="text-sm font-bold text-gray-900 mt-2.5 leading-snug">
                This week&apos;s protein trend
              </h4>
              <p className="text-xs text-gray-400 font-medium mt-0.5">
                Target: {targetProtein}g / day
              </p>
            </div>

            <div className="mt-3.5">
              {/* Progress Bar */}
              <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#2563EB] rounded-full transition-all duration-500"
                  style={{ width: `${proteinPercent}%` }}
                />
              </div>
              <div className="flex items-center justify-between mt-2 text-xs">
                <span className="font-semibold text-gray-800">57.4g avg</span>
                <span className="font-bold text-[#2563EB]">{proteinPercent}%</span>
              </div>
            </div>
          </div>

          {/* Card 2: Food Court Pick */}
          <div className="w-[250px] shrink-0 bg-white rounded-2xl p-4 shadow-xs border border-gray-150/80 flex flex-col justify-between hover:border-gray-300 transition-all">
            <div>
              <div className="flex items-center justify-between">
                <span className="bg-orange-50 text-[#E04F16] border border-orange-200/60 text-[10px] font-bold px-2 py-0.5 rounded-full select-none">
                  Mess 2 Special
                </span>
              </div>
              <h4 className="text-sm font-bold text-gray-900 mt-2.5 leading-snug">
                Best value pick at food court
              </h4>
              <p className="text-xs text-gray-400 font-medium mt-0.5 truncate">
                High protein bowl with paneer &amp; sprouts
              </p>
            </div>

            <div className="mt-3.5 pt-2 border-t border-gray-50 flex items-center justify-between text-xs">
              <span className="font-bold text-[#E04F16]">4 spots available</span>
              <button
                onClick={() => onNavigateTab('dining')}
                className="text-[11px] font-semibold text-[#2563EB] hover:underline"
              >
                Order &rarr;
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 5. Special Dinner Tonight Card */}
      <div
        onClick={onOpenViewPlan}
        className="bg-white rounded-2xl p-3.5 shadow-xs border border-gray-150/80 flex items-center justify-between cursor-pointer hover:border-gray-300 active:scale-[0.99] transition-all"
      >
        <div className="flex items-center space-x-3">
          <span className="w-3 h-3 rounded-full bg-[#E04F16] ring-4 ring-orange-100 shrink-0 ml-0.5" />
          <div>
            <h4 className="text-xs font-bold text-gray-900 leading-tight">
              Special Dinner Tonight
            </h4>
            <p className="text-[11px] text-gray-500 font-medium mt-0.5">
              Paneer Butter Masala &amp; Jeera Rice
            </p>
          </div>
        </div>
        <ChevronRight className="w-4 h-4 text-gray-400 shrink-0" />
      </div>
    </div>
  );
};
