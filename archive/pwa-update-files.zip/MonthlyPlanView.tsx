'use client';

import React, { useState, useMemo } from 'react';
import { ChevronRight, Sparkles, Zap } from 'lucide-react';
import { DailyMenuDay, UserProfile } from '@/lib/types';
import { DISH_LOOKUP } from '@/lib/data/messDishes';
import { calculateDishFitScore } from '@/lib/nutrition/fitScore';

interface MonthlyPlanViewProps {
  monthlyMenu: DailyMenuDay[];
  profile: UserProfile;
  onSelectDay: (dayNumber: number) => void;
  selectedDayNumber: number;
}

export const MonthlyPlanView: React.FC<MonthlyPlanViewProps> = ({
  monthlyMenu,
  profile,
  onSelectDay,
  selectedDayNumber,
}) => {
  const [activeWeek, setActiveWeek] = useState<number>(1);

  // Filter 7 days per week
  const daysInActiveWeek = useMemo(() => {
    const startDay = (activeWeek - 1) * 7 + 1;
    const endDay = Math.min(30, activeWeek * 7);
    return monthlyMenu.filter((d) => d.dayNumber >= startDay && d.dayNumber <= endDay);
  }, [monthlyMenu, activeWeek]);

  const getDaySummary = (day: DailyMenuDay) => {
    const lunchDishes = (day.slots.lunch || []).map((id) => DISH_LOOKUP.get(id)).filter(Boolean);
    const dinnerDishes = (day.slots.dinner || []).map((id) => DISH_LOOKUP.get(id)).filter(Boolean);

    const scoredLunch = lunchDishes
      .map((d) => calculateDishFitScore(d!, 'lunch', profile))
      .filter((s) => s.isDietCompatible && s.isAllergenFree)
      .sort((a, b) => b.score - a.score);

    const scoredDinner = dinnerDishes
      .map((d) => calculateDishFitScore(d!, 'dinner', profile))
      .filter((s) => s.isDietCompatible && s.isAllergenFree)
      .sort((a, b) => b.score - a.score);

    const topLunch = scoredLunch[0];
    const topDinner = scoredDinner[0];

    const avgScore = Math.round(
      ((topLunch?.score || 75) + (topDinner?.score || 75)) / 2
    );

    return { topLunch, topDinner, avgScore };
  };

  return (
    <div className="space-y-4 pb-20 animate-fade-in">
      {/* 1. KEY HERO BANNER */}
      <div className="bg-white border border-gray-150/80 rounded-3xl p-5 shadow-xs">
        <div className="flex items-center justify-between">
          <div>
            <div className="inline-flex items-center space-x-1 text-amber-700 text-[10px] font-bold uppercase tracking-wider mb-1 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full">
              <Sparkles className="w-3 h-3 text-amber-600" />
              <span>Full Month Preview</span>
            </div>
            <h2 className="text-xl font-extrabold text-gray-900 tracking-tight">
              30-Day Personalized Roadmap
            </h2>
          </div>
          <div className="w-11 h-11 rounded-2xl bg-orange-50 border border-orange-200/60 flex items-center justify-center text-xl shadow-xs">
            📅
          </div>
        </div>
        <p className="text-xs text-gray-500 mt-2.5 leading-relaxed font-medium">
          Pre-computed Fit Scores across your fixed mess contract. Discover which days feature high-protein targets and special feast menus.
        </p>
      </div>

      {/* 2. WEEK SELECTOR CHIPS */}
      <div className="grid grid-cols-4 gap-2">
        {[1, 2, 3, 4].map((wk) => (
          <button
            key={wk}
            onClick={() => setActiveWeek(wk)}
            className={`py-2.5 px-1 text-center rounded-2xl text-xs font-bold transition-all duration-200 cursor-pointer ${
              activeWeek === wk
                ? 'bg-[#E04F16] text-white shadow-sm'
                : 'bg-white border border-gray-200/80 text-gray-600 hover:text-gray-900 hover:bg-gray-50 shadow-xs'
            }`}
          >
            Week {wk}
          </button>
        ))}
      </div>

      {/* 3. DAYS LIST */}
      <div className="space-y-2.5">
        {daysInActiveWeek.map((day) => {
          const isSelected = day.dayNumber === selectedDayNumber;
          const { topLunch, topDinner, avgScore } = getDaySummary(day);
          const isSunday = day.dayOfWeek === 'Sunday';

          return (
            <div
              key={day.dayNumber}
              onClick={() => onSelectDay(day.dayNumber)}
              className={`p-4 rounded-3xl border transition-all duration-200 cursor-pointer bg-white ${
                isSelected
                  ? 'border-2 border-[#E04F16] shadow-sm'
                  : 'border-gray-150/80 shadow-xs hover:border-gray-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div
                    className={`w-11 h-11 rounded-2xl flex flex-col items-center justify-center text-center font-bold leading-none ${
                      isSunday
                        ? 'bg-amber-100 text-amber-900 border border-amber-300'
                        : isSelected
                        ? 'bg-[#E04F16] text-white shadow-xs'
                        : 'bg-gray-50 text-gray-700 border border-gray-200'
                    }`}
                  >
                    <span className="text-[9px] uppercase font-bold tracking-tighter">
                      DAY
                    </span>
                    <span className="text-base font-extrabold mt-0.5">
                      {day.dayNumber}
                    </span>
                  </div>

                  <div>
                    <div className="flex items-center space-x-2">
                      <h3 className="font-bold text-sm text-gray-900">
                        {day.dayOfWeek}
                      </h3>
                      {isSunday && (
                        <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200">
                          Feast Day
                        </span>
                      )}
                    </div>
                    <span className="text-xs text-gray-500 font-medium">
                      {isSelected ? 'Selected Today' : 'Tap to inspect meal'}
                    </span>
                  </div>
                </div>

                {/* Score Pill */}
                <div className="text-right flex items-center space-x-2">
                  <div className="bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-2xl text-center">
                    <div className="flex items-center space-x-0.5 justify-end">
                      <Zap className="w-3 h-3 text-amber-500 fill-amber-500" />
                      <span className="text-xs font-black text-amber-800">{avgScore}%</span>
                    </div>
                    <span className="text-[9px] text-amber-700 font-bold block">Fit Score</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </div>
              </div>

              {/* Day Highlights Preview */}
              <div className="mt-3 pt-3 border-t border-gray-100 grid grid-cols-2 gap-2 text-xs">
                <div className="bg-gray-50 p-2.5 rounded-2xl border border-gray-150">
                  <span className="text-[9px] font-bold text-gray-400 uppercase block mb-0.5 tracking-wider">
                    Lunch Top Pick
                  </span>
                  <span className="font-bold text-gray-800 truncate block">
                    {topLunch?.dish.name || 'Mess Lunch'}
                  </span>
                  <span className="text-[11px] text-blue-600 font-bold mt-0.5 block">
                    {topLunch?.dish.protein}g protein
                  </span>
                </div>

                <div className="bg-gray-50 p-2.5 rounded-2xl border border-gray-150">
                  <span className="text-[9px] font-bold text-gray-400 uppercase block mb-0.5 tracking-wider">
                    Dinner Top Pick
                  </span>
                  <span className="font-bold text-gray-800 truncate block">
                    {topDinner?.dish.name || 'Mess Dinner'}
                  </span>
                  <span className="text-[11px] text-blue-600 font-bold mt-0.5 block">
                    {topDinner?.dish.protein}g protein
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
