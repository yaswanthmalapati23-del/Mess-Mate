'use client';

import React from 'react';
import { ShieldCheck } from 'lucide-react';
import { UserProfile } from '@/lib/types';

interface HeaderProps {
  profile: UserProfile;
  currentStreak: number;
  isDark?: boolean;
  studentEmail?: string;
  todayCalories?: number;
  targetCalories?: number;
  onToggleTheme?: () => void;
  onOpenProfile: () => void;
  onSignOut?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  profile,
  todayCalories = 1240,
  targetCalories = 1900,
  onOpenProfile,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-[#F6F8FB]/95 backdrop-blur-md px-4 pt-3 pb-2 transition-colors">
      <div className="max-w-md mx-auto flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center space-x-2.5">
          <div className="w-9 h-9 rounded-full bg-white border border-gray-200/90 shadow-xs flex items-center justify-center text-lg select-none">
            🍲
          </div>
          <h1 className="font-sans font-extrabold text-lg tracking-tight text-gray-900 leading-none">
            Mess Mate
          </h1>
        </div>

        {/* Right Calorie Pill matching reference */}
        <button
          onClick={onOpenProfile}
          title="Daily Calorie Budget"
          className="flex items-center space-x-1.5 bg-white border border-gray-200/90 px-3 py-1.5 rounded-full shadow-xs hover:border-gray-300 transition-all text-xs active:scale-95"
        >
          <span className="text-orange-500 text-sm leading-none select-none">🔥</span>
          <span className="font-bold text-gray-900">
            {todayCalories.toLocaleString()}
          </span>
          <span className="text-gray-400 font-medium">
            / {targetCalories.toLocaleString()} kcal
          </span>
        </button>
      </div>

      {/* Liability Guardrail notification if active */}
      {profile.isLiabilityGuardrailActive && (
        <div className="max-w-md mx-auto mt-2 bg-emerald-50 border border-emerald-200 text-emerald-800 px-3 py-1.5 rounded-xl text-xs flex items-center justify-between shadow-xs">
          <div className="flex items-center space-x-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="font-medium text-[11px]">Balanced Nutrition Mode Active</span>
          </div>
          <button
            onClick={onOpenProfile}
            className="text-[11px] font-bold text-emerald-700 underline shrink-0"
          >
            Details
          </button>
        </div>
      )}
    </header>
  );
};

