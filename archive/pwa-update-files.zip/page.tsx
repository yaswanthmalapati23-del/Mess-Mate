'use client';

import React, { useState, useEffect } from 'react';
import { Utensils, Calendar, Coffee, TrendingUp, BellRing, ArrowLeft, PlusCircle, User } from 'lucide-react';
import { UserProfile, DailyMenuDay, StudentAccount, AuthStep } from '@/lib/types';
import {
  DEFAULT_PROFILE,
  getStoredProfile,
  saveStoredProfile,
  getMonthlyMenu,
  calculateStreak,
  getDaySummary,
  getTodayDateStr,
} from '@/lib/storage';
import { supabase, signOutStudent, upsertStudentProfile, fetchStudentProfile } from '@/lib/supabaseClient';
import { Header } from '@/components/Header';
import { StitchDashboard } from '@/components/StitchDashboard';
import { TodayPlanView } from '@/components/TodayPlanView';
import { MonthlyPlanView } from '@/components/MonthlyPlanView';
import { FoodCourtLogger } from '@/components/FoodCourtLogger';
import { DailyTracker } from '@/components/DailyTracker';
import { OnboardingModal } from '@/components/OnboardingModal';
import { AuthModal } from '@/components/AuthModal';

const BurgerIcon = ({ className = 'w-5 h-5' }: { className?: string }) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <path d="M4 11h16a1 1 0 0 0 .8-1.6C19.7 7.7 16.2 5 12 5S4.3 7.7 3.2 9.4A1 1 0 0 0 4 11z" />
    <path d="M4 15h16" />
    <path d="M5 19h14a2 2 0 0 0 2-2H3a2 2 0 0 0 2 2z" />
  </svg>
);

type MainTab = 'home' | 'dining' | 'log' | 'monthly' | 'tracker';

export default function Home() {
  const [profile, setProfile] = useState<UserProfile>(DEFAULT_PROFILE);
  const [student, setStudent] = useState<StudentAccount | null>(null);
  const [isClient, setIsClient] = useState(false);
  const [activeTab, setActiveTab] = useState<MainTab>('home');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalStep, setAuthModalStep] = useState<AuthStep>('login');
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);
  const [monthlyMenu, setMonthlyMenu] = useState<DailyMenuDay[]>([]);
  const [selectedDayNumber, setSelectedDayNumber] = useState(1);
  const [streakCount, setStreakCount] = useState(0);
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    setIsClient(true);

    // Initialize menu, streak, and calendar day immediately
    const menu = getMonthlyMenu();
    setMonthlyMenu(menu);

    const { currentStreak } = calculateStreak();
    setStreakCount(currentStreak);

    const day = Math.min(30, Math.max(1, new Date().getDate()));
    setSelectedDayNumber(day);

    const existingProfile = getStoredProfile();
    if (existingProfile) {
      setProfile(existingProfile);
    }

    // 1. Check local session cache for fast load
    try {
      const cachedStudent = localStorage.getItem('mess_mate_auth_student');
      if (cachedStudent) {
        const parsed: StudentAccount = JSON.parse(cachedStudent);
        setStudent(parsed);
      }
    } catch (e) {}

    // 2. Supabase auth state listener
    let authSubscription: { unsubscribe: () => void } | null = null;

    if (supabase) {
      supabase.auth.getSession().then(async ({ data: { session } }) => {
        if (session?.user) {
          const domain = session.user.email?.split('@')[1] || 'vitapstudent.ac.in';
          const { onboardingCompleted, profile: dbProfile } = await fetchStudentProfile(session.user.id);
          const hasPassword = Boolean(session.user.user_metadata?.has_password);

          const activeStudent: StudentAccount = {
            id: session.user.id,
            email: session.user.email || '',
            collegeDomain: domain,
            onboardingCompleted,
            profile: dbProfile,
          };
          setStudent(activeStudent);
          try {
            localStorage.setItem('mess_mate_auth_student', JSON.stringify(activeStudent));
          } catch (e) {}

          // A. If student does NOT have a password set yet, route directly to Create Password screen!
          if (!hasPassword) {
            setAuthModalStep('create_password');
            setIsAuthModalOpen(true);
            setIsOnboardingOpen(false);
            return;
          }

          // B. If student has password and onboarding is completed:
          if (onboardingCompleted && dbProfile) {
            setProfile(dbProfile);
            saveStoredProfile(dbProfile);
            setIsAuthModalOpen(false);
            setIsOnboardingOpen(false);
          } else {
            // C. Student has password but hasn't completed onboarding biomarkers:
            setIsAuthModalOpen(false);
            try {
              localStorage.removeItem('mess_mate_profile');
            } catch (e) {}
            setIsOnboardingOpen(true);
          }
        } else {
          setStudent(null);
          setAuthModalStep('login');
          setIsAuthModalOpen(true);
          setIsOnboardingOpen(false);
        }
      });

      const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
        if (event === 'SIGNED_IN' && session?.user) {
          const domain = session.user.email?.split('@')[1] || 'vitapstudent.ac.in';
          const { onboardingCompleted, profile: dbProfile } = await fetchStudentProfile(session.user.id);
          const hasPassword = Boolean(session.user.user_metadata?.has_password);
          const activeStudent: StudentAccount = {
            id: session.user.id,
            email: session.user.email || '',
            collegeDomain: domain,
            onboardingCompleted,
            profile: dbProfile,
          };
          setStudent(activeStudent);
          try {
            localStorage.setItem('mess_mate_auth_student', JSON.stringify(activeStudent));
          } catch (e) {}

          if (hasPassword && onboardingCompleted && dbProfile) {
            setProfile(dbProfile);
            saveStoredProfile(dbProfile);
            setIsAuthModalOpen(false);
            setIsOnboardingOpen(false);
          }
        } else if (event === 'SIGNED_OUT') {
          setStudent(null);
          setAuthModalStep('login');
          setIsAuthModalOpen(true);
          setIsOnboardingOpen(false);
          try {
            localStorage.removeItem('mess_mate_auth_student');
            localStorage.removeItem('mess_mate_profile');
          } catch (e) {}
        }
      });

      authSubscription = authListener?.subscription || null;
    }

    return () => {
      authSubscription?.unsubscribe();
    };
  }, []);

  const handleToggleTheme = () => {
    setIsDark((prev) => {
      const next = !prev;
      if (next) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      return next;
    });
  };

  const handleAuthSuccess = async (authenticatedStudent: StudentAccount, isNewStudent: boolean) => {
    setIsAuthModalOpen(false);

    // Verify DB status
    const { onboardingCompleted, profile: dbProfile } = await fetchStudentProfile(authenticatedStudent.id);
    const isComplete = Boolean(onboardingCompleted && dbProfile);

    const activeStudent: StudentAccount = {
      ...authenticatedStudent,
      onboardingCompleted: isComplete,
      profile: dbProfile || authenticatedStudent.profile,
    };

    setStudent(activeStudent);
    try {
      localStorage.setItem('mess_mate_auth_student', JSON.stringify(activeStudent));
    } catch (e) {}

    if (isNewStudent || !isComplete || !dbProfile) {
      try {
        localStorage.removeItem('mess_mate_profile');
      } catch (e) {}
      setIsOnboardingOpen(true);
    } else {
      setProfile(dbProfile);
      saveStoredProfile(dbProfile);
      setIsOnboardingOpen(false);
    }
  };

  const handleSignOut = async () => {
    await signOutStudent();
    setStudent(null);
    setIsAuthModalOpen(true);
  };

  const handleProfileSave = async (newProfile: UserProfile) => {
    setProfile(newProfile);
    saveStoredProfile(newProfile);
    setIsOnboardingOpen(false);

    if (student) {
      const updatedStudent: StudentAccount = {
        ...student,
        onboardingCompleted: true,
        profile: newProfile,
      };
      setStudent(updatedStudent);
      try {
        localStorage.setItem('mess_mate_auth_student', JSON.stringify(updatedStudent));
      } catch (e) {}

      // Sync to Supabase public.students table
      await upsertStudentProfile(newProfile, student.id, student.email);
    }
  };

  const handleRefreshData = () => {
    const menu = getMonthlyMenu();
    setMonthlyMenu(menu);
    const { currentStreak } = calculateStreak();
    setStreakCount(currentStreak);
  };

  const todayStr = getTodayDateStr();
  const todaySummary = getDaySummary(todayStr, profile);

  if (!isClient) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F6F8FB]">
        <div className="flex flex-col items-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-[#E04F16] flex items-center justify-center text-white text-2xl animate-pulse shadow-md">
            🍲
          </div>
          <span className="text-xs font-bold text-gray-500 font-sans">Loading Mess Mate...</span>
        </div>
      </div>
    );
  }

  const currentDayMenu =
    monthlyMenu.find((d) => d.dayNumber === selectedDayNumber) || monthlyMenu[0] || {
      dayNumber: 1,
      dayOfWeek: 'Monday',
      slots: { breakfast: [], lunch: [], snacks: [], dinner: [] },
    };

  return (
    <div className="min-h-screen bg-[#F6F8FB] text-gray-900 flex flex-col justify-between selection:bg-[#E04F16] selection:text-white transition-colors duration-200">
      {/* Top Header matching reference */}
      <Header
        profile={profile}
        currentStreak={streakCount}
        isDark={isDark}
        todayCalories={todaySummary.caloriesConsumed > 0 ? todaySummary.caloriesConsumed : 1240}
        targetCalories={profile.targetCalories || 1900}
        studentEmail={student?.email}
        onToggleTheme={handleToggleTheme}
        onOpenProfile={() => setIsOnboardingOpen(true)}
        onSignOut={handleSignOut}
      />

      {/* Main Content Area */}
      <main className="max-w-md mx-auto w-full px-4 pt-1 flex-1 pb-4">
        {/* Tab 1: Stitch Home Dashboard */}
        {activeTab === 'home' && (
          <StitchDashboard
            profile={profile}
            studentEmail={student?.email}
            currentDayMenu={currentDayMenu}
            todaySummary={todaySummary}
            streakCount={streakCount}
            onOpenViewPlan={() => setActiveTab('log')}
            onNavigateTab={(tab) => setActiveTab(tab)}
            onOpenLogMeal={() => setActiveTab('log')}
            onOpenProfile={() => setIsOnboardingOpen(true)}
          />
        )}

        {/* Back header for sub-views */}
        {activeTab !== 'home' && (
          <div className="mb-3.5 flex items-center justify-between pt-1">
            <button
              onClick={() => setActiveTab('home')}
              className="flex items-center space-x-1.5 text-xs font-bold text-gray-700 hover:text-gray-900 bg-white border border-gray-200/90 px-3 py-1.5 rounded-full shadow-xs active:scale-95 transition-all cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Home</span>
            </button>
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">
              {activeTab === 'dining' ? 'Food Court' : activeTab === 'log' ? "Today's Plan" : activeTab === 'monthly' ? '30-Day Plan' : 'Habit Tracker'}
            </span>
          </div>
        )}

        {/* Primary View: Today's Plan */}
        {activeTab === 'log' && (
          <TodayPlanView
            currentDayMenu={currentDayMenu}
            profile={profile}
            onMealLogged={handleRefreshData}
            isDark={isDark}
          />
        )}

        {/* Key "Wow" View: 30-Day Plan */}
        {activeTab === 'monthly' && (
          <MonthlyPlanView
            monthlyMenu={monthlyMenu}
            profile={profile}
            selectedDayNumber={selectedDayNumber}
            onSelectDay={(dayNum) => {
              setSelectedDayNumber(dayNum);
              setActiveTab('log');
            }}
          />
        )}

        {/* Phase 3 Logging: Food Court */}
        {activeTab === 'dining' && (
          <FoodCourtLogger profile={profile} onLogUpdated={handleRefreshData} />
        )}

        {/* Phase 4 Retention: Habit Tracker */}
        {activeTab === 'tracker' && <DailyTracker profile={profile} />}
      </main>

      {/* Sticky Bottom Navigation Bar matching Stitch */}
      <nav className="sticky bottom-0 z-40 bg-white/95 backdrop-blur-md border-t border-gray-150 px-4 py-2 shadow-lg">
        <div className="max-w-md mx-auto flex items-center justify-around">
          {/* Tab 1: Home */}
          <button
            onClick={() => setActiveTab('home')}
            className={`transition-all duration-200 cursor-pointer ${
              activeTab === 'home'
                ? 'bg-[#2563EB] text-white px-5 py-1.5 rounded-full flex flex-col items-center justify-center font-bold text-[10px] shadow-sm'
                : 'text-gray-500 hover:text-gray-900 flex flex-col items-center justify-center py-1 px-3 text-[10px] font-medium'
            }`}
          >
            <Utensils className={activeTab === 'home' ? 'w-4 h-4 mb-0.5 text-white' : 'w-5 h-5 mb-0.5 text-gray-500'} />
            <span>Home</span>
          </button>

          {/* Tab 2: Dining */}
          <button
            onClick={() => setActiveTab('dining')}
            className={`transition-all duration-200 cursor-pointer ${
              activeTab === 'dining'
                ? 'bg-[#2563EB] text-white px-5 py-1.5 rounded-full flex flex-col items-center justify-center font-bold text-[10px] shadow-sm'
                : 'text-gray-500 hover:text-gray-900 flex flex-col items-center justify-center py-1 px-3 text-[10px] font-medium'
            }`}
          >
            <BurgerIcon className={activeTab === 'dining' ? 'w-4 h-4 mb-0.5 text-white' : 'w-5 h-5 mb-0.5 text-gray-500'} />
            <span>Dining</span>
          </button>

          {/* Tab 3: Log */}
          <button
            onClick={() => setActiveTab('log')}
            className={`transition-all duration-200 cursor-pointer ${
              activeTab === 'log'
                ? 'bg-[#2563EB] text-white px-5 py-1.5 rounded-full flex flex-col items-center justify-center font-bold text-[10px] shadow-sm'
                : 'text-gray-500 hover:text-gray-900 flex flex-col items-center justify-center py-1 px-3 text-[10px] font-medium'
            }`}
          >
            <PlusCircle className={activeTab === 'log' ? 'w-4 h-4 mb-0.5 text-white' : 'w-5 h-5 mb-0.5 text-gray-500'} />
            <span>Log</span>
          </button>

          {/* Tab 4: Profile */}
          <button
            onClick={() => setIsOnboardingOpen(true)}
            className="text-gray-500 hover:text-gray-900 flex flex-col items-center justify-center py-1 px-3 text-[10px] font-medium transition-all cursor-pointer"
          >
            <User className="w-5 h-5 mb-0.5 text-gray-500" />
            <span>Profile</span>
          </button>
        </div>
      </nav>

      {/* College Email OTP Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        initialStep={authModalStep}
        studentEmail={student?.email}
        onAuthSuccess={handleAuthSuccess}
        onClose={() => setIsAuthModalOpen(false)}
      />

      {/* Onboarding & Profile Modal */}
      <OnboardingModal
        isOpen={isOnboardingOpen}
        currentProfile={profile}
        studentEmail={student?.email}
        onSave={handleProfileSave}
        onClose={() => {
          if (!student || student.onboardingCompleted) {
            setIsOnboardingOpen(false);
          }
        }}
      />
    </div>
  );
}
